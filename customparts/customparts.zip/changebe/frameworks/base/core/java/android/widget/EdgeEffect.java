import android.os.SystemProperties; // [CUSTOM BOUNCE] Added import


public class EdgeEffect {
    // ....
    // ....
    // [CUSTOM BOUNCE] Constants
    private static final String PROP_USE_BOUNCE = "persist.sys.overscroll.bounce";
    private static final String PROP_STIFFNESS = "debug.bounce.stiff";
    private static final String PROP_DAMPING = "debug.bounce.damp";
    private static final String PROP_PULL = "debug.bounce.pull";
    private static final String PROP_FLING = "debug.bounce.fling";
    // [CUSTOM BOUNCE] End
    // ....
    // ....
    // [CUSTOM BOUNCE] Fields
    private boolean mUseCustomBounce = false;
    private final SpringDynamics mSpring;
    // [CUSTOM BOUNCE] End
    // ....
    // ....
    public EdgeEffect(@NonNull Context context, @Nullable AttributeSet attrs) {
        // ....
        // ....
        // [CUSTOM BOUNCE] Initialize
        mSpring = new SpringDynamics();
        updateBounceMode();
    }
    // [CUSTOM BOUNCE] Safe Property Readers to prevent SecurityException crashes
    private void updateBounceMode() {
        mUseCustomBounce = getBooleanProp(PROP_USE_BOUNCE, false);
    }

    private static boolean getBooleanProp(String key, boolean def) {
        try { return SystemProperties.getBoolean(key, def); } catch (Throwable t) { return def; }
    }
    private static float getFloatProp(String key, float def) {
        try {
            String val = SystemProperties.get(key, null);
            return (val != null && !val.isEmpty()) ? Float.parseFloat(val) : def;
        } catch (Throwable t) { return def; }
    }
    private static int getIntProp(String key, int def) {
        try { return SystemProperties.getInt(key, def); } catch (Throwable t) { return def; }
    }
    // [CUSTOM BOUNCE END]
    // ....
    // ....
    public boolean isFinished() {
        // [CUSTOM BOUNCE]
        if (mUseCustomBounce) {
            return !mSpring.isRunning() && mSpring.mValue == 0;
        }
        // ....
        // ....
    }
    public void finish() {
        // [CUSTOM BOUNCE]
        if (mUseCustomBounce) {
            mSpring.cancel();
            mSpring.mValue = 0;
            mSpring.mVelocity = 0;
        }
        // ....
        // ....
    }
    public void onPull(float deltaDistance, float displacement) {
        // ....
        // ....
        // [CUSTOM BOUNCE]
        if (mUseCustomBounce) {
            mState = STATE_PULL;
            mSpring.cancel();

            float pullCoeff = getFloatProp(PROP_PULL, 0.5f);

            float currentTranslation = mSpring.mValue;
            float height = (mHeight > 0) ? mHeight : 1000f; 
            float rawMove = deltaDistance * height;
            float maxRange = height * 0.5f;
            
            boolean isPullingAway = (currentTranslation > 0 && rawMove > 0) || (currentTranslation < 0 && rawMove < 0);
            
            float change;
            if (isPullingAway) {
                 float distanceRatio = Math.min(Math.abs(currentTranslation) / maxRange, 1f);
                 float resistance = 1f - distanceRatio;
                 change = rawMove * pullCoeff * resistance;
            } else {
                 change = rawMove * 1.1f;
            }
            
            float nextTranslation = currentTranslation + change;
            if ((currentTranslation > 0 && nextTranslation < 0) || (currentTranslation < 0 && nextTranslation > 0)) {
                nextTranslation = 0f;
            }
            if (nextTranslation < 0) nextTranslation = 0;

            mSpring.mValue = nextTranslation;
            mDistance = nextTranslation / height; 
            return;
        }
        // [CUSTOM BOUNCE END]
        // [CUSTOM BOUNCE END]

        // ....
        // ....
    }
    public float onPullDistance(float deltaDistance, float displacement) {
        // ....
        // ....
        
        // [CUSTOM BOUNCE]
        if (mUseCustomBounce) {
             onPull(deltaDistance, displacement);
             return deltaDistance;
        }
        // [CUSTOM BOUNCE END]

        // ....
        // ....
        // ....
    }
    public void onRelease() {
        // ....

        // [CUSTOM BOUNCE]
        if (mUseCustomBounce) {
            if (mSpring.mValue != 0) {
                float stiffness = (float) getIntProp(PROP_STIFFNESS, 450);
                float damping = getFloatProp(PROP_DAMPING, 0.7f);

                mSpring.setStiffness(stiffness);
                mSpring.setDampingRatio(damping);
                mSpring.setTargetValue(0);
                mSpring.setVelocity(0);
                mSpring.start();
            }
            mState = STATE_RECEDE;
            return;
        }
        // [CUSTOM BOUNCE END]

        // ....
        // ....
        // ....
    }
    public void onAbsorb(int velocity) {
        // ....
        
        // [CUSTOM BOUNCE]
        if (mUseCustomBounce) {
            mState = STATE_RECEDE;
            mSpring.cancel();
            
            float flingMult = getFloatProp(PROP_FLING, 0.6f);
            float stiffness = (float) getIntProp(PROP_STIFFNESS, 450);
            float damping = getFloatProp(PROP_DAMPING, 0.7f);
            
            float velocityPx = velocity * flingMult;
            float maxVel = 15000f;
            if (Math.abs(velocityPx) > maxVel) velocityPx = Math.signum(velocityPx) * maxVel;

            mSpring.setStiffness(stiffness);
            mSpring.setDampingRatio(damping);
            mSpring.setTargetValue(0);
            mSpring.setVelocity(velocityPx);
            mSpring.start();
            return;
        }
        // [CUSTOM BOUNCE END]

        // ....
        // ....
    }
    public boolean draw(Canvas canvas) {
        // [CUSTOM BOUNCE]
        if (mUseCustomBounce && canvas instanceof RecordingCanvas) {
            if (mSpring.isRunning()) {
                mSpring.doFrame(System.nanoTime());
            }

            float currentTranslation = mSpring.mValue;
            mDistance = (mHeight > 0) ? currentTranslation / mHeight : 0;

            if (currentTranslation != 0 || mSpring.isRunning()) {
                RecordingCanvas recordingCanvas = (RecordingCanvas) canvas;
                if (mTmpMatrix == null) {
                    mTmpMatrix = new Matrix();
                    mTmpPoints = new float[12];
                }
                recordingCanvas.getMatrix(mTmpMatrix);

                mTmpPoints[0] = 0; mTmpPoints[1] = 0; 
                mTmpPoints[2] = mWidth; mTmpPoints[3] = 0;
                mTmpPoints[4] = mWidth; mTmpPoints[5] = mHeight; 
                mTmpPoints[6] = 0; mTmpPoints[7] = mHeight;
                mTmpPoints[8] = 0; mTmpPoints[9] = 0;
                mTmpPoints[10] = 0; mTmpPoints[11] = 100;
                mTmpMatrix.mapPoints(mTmpPoints);

                RenderNode renderNode = recordingCanvas.mNode;
                
                float vecY_Y = mTmpPoints[11] - mTmpPoints[9];
                float vecY_X = mTmpPoints[10] - mTmpPoints[8];
                
                // === FIX CRASH: Safe Unstretch ===
                float safeW = (mWidth > 0) ? mWidth : 1f;
                float safeH = (mHeight > 0) ? mHeight : 1f;
                renderNode.stretch(0f, 0f, safeW, safeH);
                // =================================

                if (Math.abs(vecY_Y) > Math.abs(vecY_X)) {
                    float sign = vecY_Y > 0 ? 1f : -1f;
                    renderNode.setTranslationY(currentTranslation * sign);
                } else {
                    float sign = vecY_X > 0 ? 1f : -1f;
                    renderNode.setTranslationX(currentTranslation * sign);
                }
                
                return true; 
            } else {
                RecordingCanvas recordingCanvas = (RecordingCanvas) canvas;
                RenderNode renderNode = recordingCanvas.mNode;
                if (renderNode.getTranslationY() != 0 || renderNode.getTranslationX() != 0) {
                     renderNode.setTranslationY(0);
                     renderNode.setTranslationX(0);
                }
            }
            return false;
        }
        // [CUSTOM BOUNCE END]

        // ....
        // ....
    }
    // [CUSTOM BOUNCE] Physics Engine (Passive Mode - No Choreographer)
    private static class SpringDynamics {
        private float mStiffness = 450.0f;
        private float mDampingRatio = 0.7f;
        
        public float mValue;
        public float mVelocity;
        public float mTargetValue = 0f;
        private boolean mIsRunning = false;
        private long mLastFrameTimeNanos = 0;
        
        private static final float VALUE_THRESHOLD = 0.5f; 
        private static final float VELOCITY_THRESHOLD = 1.0f; 

        public void setStiffness(float stiffness) { mStiffness = stiffness > 0 ? stiffness : 0.1f; }
        public void setDampingRatio(float dampingRatio) { mDampingRatio = dampingRatio >= 0 ? dampingRatio : 0; }
        public void setTargetValue(float targetValue) { mTargetValue = targetValue; }
        public void setVelocity(float velocity) { mVelocity = velocity; }
        public boolean isRunning() { return mIsRunning; }

        public void start() {
            if (mIsRunning) return;
            mIsRunning = true;
            mLastFrameTimeNanos = System.nanoTime();
        }

        public void cancel() { mIsRunning = false; }

        public void doFrame(long frameTimeNanos) {
            if (!mIsRunning) return;

            long deltaTimeNanos = frameTimeNanos - mLastFrameTimeNanos;
            if (deltaTimeNanos > 100_000_000) deltaTimeNanos = 16_000_000; 
            mLastFrameTimeNanos = frameTimeNanos;

            float dt = deltaTimeNanos / 1_000_000_000.0f;
            float displacement = mValue - mTargetValue;
            float dampingCoefficient = 2 * mDampingRatio * (float) Math.sqrt(mStiffness);
            float force = -mStiffness * displacement - dampingCoefficient * mVelocity;
            
            mVelocity += force * dt;
            mValue += mVelocity * dt;

            if (isAtEquilibrium()) {
                mValue = mTargetValue;
                mVelocity = 0;
                cancel();
            }
        }

        private boolean isAtEquilibrium() {
            return Math.abs(mVelocity) < VELOCITY_THRESHOLD && 
                   Math.abs(mValue - mTargetValue) < VALUE_THRESHOLD;
        }
    }
    // [CUSTOM BOUNCE END]
}