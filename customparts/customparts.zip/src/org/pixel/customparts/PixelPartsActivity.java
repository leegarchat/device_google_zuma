package org.pixel.testcustomparts;

import android.os.Bundle;
import com.android.settingslib.collapsingtoolbar.CollapsingToolbarBaseActivity;

public class PixelPartsActivity extends CollapsingToolbarBaseActivity {

    private static final String TAG_PARTS = "pixel_parts";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Проверка на savedInstanceState важна, чтобы не накладывать фрагменты друг на друга при повороте экрана
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(com.android.settingslib.collapsingtoolbar.R.id.content_frame,
                            new PixelPartsFragment(), TAG_PARTS)
                    .commit();
        }
    }
}