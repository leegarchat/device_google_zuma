package org.pixel.testcustomparts;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemProperties;
import androidx.preference.PreferenceManager;
import android.util.Log;

public final class ThermalUtils {

    public static final String KEY_THERMAL_BATTERY = "thermal_battery_mode";
    public static final String KEY_THERMAL_SOC = "thermal_soc_mode";
    private static final String TAG = "PixelPartsThermal";
    private static final String PROP_BATTERY = "persist.sys.pixelparts.battery";
    private static final String PROP_SOC = "persist.sys.pixelparts.soc";
    private static final String PROP_CONFIG_TARGET = "persist.sys.pixelparts.thermal_config";

    public static void updateThermalProps(Context context) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);

        String batteryMode = sharedPrefs.getString(KEY_THERMAL_BATTERY, "stock");
        String socMode = sharedPrefs.getString(KEY_THERMAL_SOC, "stock");

        Log.d(TAG, "Updating thermal props. Battery: " + batteryMode + ", SoC: " + socMode);
        SystemProperties.set(PROP_BATTERY, batteryMode);
        SystemProperties.set(PROP_SOC, socMode);
        String socAddName = "";
        if (!"stock".equals(socMode)) {
            socAddName = "_soc_" + socMode;
        }
        String batteryAddName = "";
        if (!"stock".equals(batteryMode)) {
            batteryAddName = "_battery_" + batteryMode;
        }
        String configFileName = "thermal_info_config" + socAddName + batteryAddName + ".json";
        SystemProperties.set(PROP_CONFIG_TARGET, configFileName);
        
        Log.d(TAG, "Set " + PROP_CONFIG_TARGET + " to " + configFileName);
    }
}