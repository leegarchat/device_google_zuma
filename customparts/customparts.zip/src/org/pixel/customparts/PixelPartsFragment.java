package org.pixel.testcustomparts;

import android.os.Bundle;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
// import androidx.fragment.app.FragmentTransaction;

import org.pixel.testcustomparts.parts.DozePart;
import org.pixel.testcustomparts.parts.ImsPart;
import org.pixel.testcustomparts.parts.LauncherPart;
import org.pixel.testcustomparts.parts.Part;
import org.pixel.testcustomparts.parts.ThermalPart;
// OverscrollPart больше не нужен
import org.pixel.testcustomparts.parts.OverscrollGUIFragment; // Импорт нашего нового фрагмента
import org.pixel.testcustomparts.parts.OverscrollActivity; 
import android.content.Intent; 
import java.util.ArrayList;
import java.util.List;

public class PixelPartsFragment extends PreferenceFragmentCompat 
        implements Preference.OnPreferenceChangeListener {

    private List<Part> mParts = new ArrayList<>();

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.pixel_custom_parts_settings, rootKey);
        
        mParts.add(new ImsPart());
        mParts.add(new LauncherPart());
        mParts.add(new DozePart());
        mParts.add(new ThermalPart());
        
        // --- ЗАМЕНА ЛОГИКИ ПЕРЕХОДА ---
        Preference overscrollPref = findPreference("overscroll_settings_entry");
        if (overscrollPref != null) {
            overscrollPref.setOnPreferenceClickListener(preference -> {
                // Запускаем новую Activity вместо подмены фрагмента
                Intent intent = new Intent(getContext(), OverscrollActivity.class);
                startActivity(intent);
                return true;
            });
        }

        for (Part part : mParts) {
            part.onCreate(this);
        }
    }
    
    // ... остальной код (onPreferenceChange, onResume, etc) без изменений
    @Override
    public boolean onPreferenceChange(Preference preference, Object newValue) {
        for (Part part : mParts) {
            if (part.onPreferenceChange(preference, newValue)) return true;
        }
        return false;
    }

    @Override
    public void onResume() {
        super.onResume();
        for (Part part : mParts) part.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        for (Part part : mParts) part.onPause();
    }
}