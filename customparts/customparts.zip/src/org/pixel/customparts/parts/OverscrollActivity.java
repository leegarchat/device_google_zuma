package org.pixel.testcustomparts.parts;

import android.os.Bundle;
// Заменяем AppCompatActivity на FragmentActivity
import androidx.fragment.app.FragmentActivity; 

public class OverscrollActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(android.R.id.content, new OverscrollGUIFragment())
                    .commit();
        }
    }
}