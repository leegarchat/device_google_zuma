package org.pixel.testcustomparts.parts;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONObject;
import org.pixel.testcustomparts.R;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class OverscrollGUIFragment extends Fragment {

    private static final String TAG = "OverscrollSettings";

    // Request Codes
    private static final int REQ_CREATE_FILE = 101;
    private static final int REQ_OPEN_FILE = 102;

    // --- KEYS (Settings.Secure) ---
    private static final String KEY_ENABLED = "overscroll_enabled";
    private static final String KEY_LOGGING = "overscroll_logging";
    private static final String KEY_PACKAGES_CONFIG = "overscroll_packages_config";
    private static final String KEY_SAVED_PROFILES = "overscroll_saved_profiles";
    
    // Physics
    private static final String KEY_PULL_COEFF = "overscroll_pull";
    private static final String KEY_STIFFNESS = "overscroll_stiffness";
    private static final String KEY_DAMPING = "overscroll_damping";
    private static final String KEY_FLING = "overscroll_fling";
    
    // Visuals - Old keys (keep for compatibility)
    private static final String KEY_FOLLOW_ENABLE = "overscroll_follow_enable";
    private static final String KEY_FOLLOW_INTENSITY = "overscroll_follow_intensity";
    private static final String KEY_SKEW_ENABLE = "overscroll_skew_enable";
    private static final String KEY_TILT_INTENSITY = "overscroll_tilt_intensity";
    private static final String KEY_SCALE_MODE = "overscroll_scale_mode";
    private static final String KEY_SCALE_INTENSITY = "overscroll_scale_intensity";
    private static final String KEY_SCALE_ANCHOR_Y = "overscroll_scale_anchor_y";
    private static final String KEY_SCALE_ANCHOR_X = "overscroll_scale_anchor_x";
    private static final String KEY_SCALE_LIMIT_MIN = "overscroll_scale_limit_min";
    private static final String KEY_COEFF_ROT_Y = "overscroll_coeff_rot_y";
    private static final String KEY_COEFF_ROT_X = "overscroll_coeff_rot_x";
    
    // Experimental
    private static final String KEY_INPUT_SMOOTH_FACTOR = "overscroll_input_smooth";
    private static final String KEY_RESISTANCE_EXPONENT = "overscroll_res_exponent";
    private static final String KEY_PHYSICS_MIN_VEL = "overscroll_physics_min_vel";
    private static final String KEY_PHYSICS_MIN_VAL = "overscroll_physics_min_val";
    private static final String KEY_COEFF_CAMERA = "overscroll_coeff_camera";
    
    private static final String KEY_LERP_MAIN_IDLE = "overscroll_lerp_main_idle";
    private static final String KEY_LERP_MAIN_RUN = "overscroll_lerp_main_run";
    private static final String KEY_LERP_FINGER_TRACK_PULL = "overscroll_lerp_finger_track_pull";
    private static final String KEY_LERP_FINGER_TRACK_RELEASE = "overscroll_lerp_finger_track_release";

    private List<Runnable> globalResetActions = new ArrayList<>();
    private List<Runnable> uiUpdateRunnables = new ArrayList<>();
    private Context mContext;

    private LinearLayout appsContainer;
    private LinearLayout profilesContainer;
    private Switch masterSwitchRef;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_overscroll_gui, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContext = requireContext();

        try {
            setupMasterSwitch(view);
            setupInternalProfiles(view);
            setupBasic(view);
            setupVisualGroups(view);
            setupExperimental(view);
            setupAppConfig(view);
            setupGlobalReset(view);
        } catch (Exception e) {
            Log.e(TAG, "Init Error", e);
            Toast.makeText(mContext, R.string.os_msg_init_error, Toast.LENGTH_LONG).show();
        }
    }

    // ==========================================
    // MASTER SWITCH
    // ==========================================

    private void setupMasterSwitch(View root) {
        Switch masterSw = root.findViewById(R.id.sw_master_enable);
        if (masterSw == null) return;
        
        masterSwitchRef = masterSw;
        boolean isEnabled = getSecureInt(KEY_ENABLED, 1) == 1;
        masterSw.setChecked(isEnabled);

        masterSw.setOnCheckedChangeListener((v, checked) -> {
            putSecureInt(KEY_ENABLED, checked ? 1 : 0);
        });
        
        globalResetActions.add(() -> {
            putSecureInt(KEY_ENABLED, 1);
            masterSw.setChecked(true);
        });
    }

    // ==========================================
    // INTERNAL PROFILES
    // ==========================================

    private void setupInternalProfiles(View root) {
        profilesContainer = root.findViewById(R.id.ll_profiles_list);
        View btnSave = root.findViewById(R.id.btn_save_profile);
        View btnExport = root.findViewById(R.id.btn_export_json);
        View btnImport = root.findViewById(R.id.btn_import_json);

        if (btnSave != null) {
            btnSave.setOnClickListener(v -> showSaveProfileDialog());
        }
        
        if (btnExport != null) {
            btnExport.setOnClickListener(v -> startFileExport());
        }
        
        if (btnImport != null) {
            btnImport.setOnClickListener(v -> startFileImport());
        }
        
        refreshProfilesList();
    }

    private void showSaveProfileDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle(R.string.os_dialog_save_profile_title);
        
        final EditText input = new EditText(mContext);
        input.setHint(R.string.os_hint_profile_name);
        input.setTextColor(Color.WHITE);
        
        LinearLayout container = new LinearLayout(mContext);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(60, 20, 60, 20);
        container.addView(input);
        builder.setView(container);

        builder.setPositiveButton(R.string.os_btn_save, (d, w) -> {
            String name = input.getText().toString().trim();
            if (!name.isEmpty()) {
                saveCurrentSettingsAsProfile(name);
            }
        });
        builder.setNegativeButton(R.string.os_btn_cancel, null);
        builder.show();
    }

    private void saveCurrentSettingsAsProfile(String name) {
        try {
            JSONObject profileObj = new JSONObject();
            profileObj.put("name", name);
            profileObj.put("data", collectCurrentSettingsJson());

            String currentProfiles = Settings.Secure.getString(mContext.getContentResolver(), KEY_SAVED_PROFILES);
            JSONArray arr;
            if (currentProfiles == null || currentProfiles.isEmpty()) {
                arr = new JSONArray();
            } else {
                arr = new JSONArray(currentProfiles);
            }
            arr.put(profileObj);

            Settings.Secure.putString(mContext.getContentResolver(), KEY_SAVED_PROFILES, arr.toString());
            refreshProfilesList();
            Toast.makeText(mContext, R.string.os_msg_profile_saved, Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(mContext, R.string.os_msg_profile_save_error, Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshProfilesList() {
        if (profilesContainer == null) return;
        profilesContainer.removeAllViews();

        String raw = Settings.Secure.getString(mContext.getContentResolver(), KEY_SAVED_PROFILES);
        if (raw == null || raw.isEmpty()) return;

        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject item = arr.getJSONObject(i);
                String name = item.getString("name");
                final int index = i;

                LinearLayout row = new LinearLayout(mContext);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(16, 16, 16, 16);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setBackgroundColor(0xFF2D2D2D);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 
                    ViewGroup.LayoutParams.WRAP_CONTENT
                );
                lp.bottomMargin = 8;
                row.setLayoutParams(lp);

                TextView tvName = new TextView(mContext);
                tvName.setText(name);
                tvName.setTextColor(Color.WHITE);
                tvName.setTextSize(16f);
                tvName.setLayoutParams(new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                ));
                
                row.setOnClickListener(v -> loadProfileInternal(item));

                ImageView btnDelete = new ImageView(mContext);
                btnDelete.setImageResource(android.R.drawable.ic_menu_delete);
                btnDelete.setColorFilter(0xFFCF6679);
                btnDelete.setPadding(16, 8, 16, 8);
                btnDelete.setOnClickListener(v -> deleteProfile(index));

                row.addView(tvName);
                row.addView(btnDelete);
                profilesContainer.addView(row);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error parsing profiles", e);
        }
    }

    private void deleteProfile(int index) {
        try {
            String raw = Settings.Secure.getString(mContext.getContentResolver(), KEY_SAVED_PROFILES);
            if (raw == null) return;
            JSONArray arr = new JSONArray(raw);
            
            JSONArray newArr = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                if (i != index) newArr.put(arr.get(i));
            }
            
            Settings.Secure.putString(mContext.getContentResolver(), KEY_SAVED_PROFILES, newArr.toString());
            refreshProfilesList();
        } catch (Exception e) {
            Log.e(TAG, "Error deleting profile", e);
        }
    }

    private void loadProfileInternal(JSONObject profileWrapper) {
        try {
            JSONObject data = profileWrapper.getJSONObject("data");
            applySettingsFromJson(data);
            Toast.makeText(mContext, 
                getString(R.string.os_msg_profile_loaded, profileWrapper.getString("name")), 
                Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(mContext, R.string.os_msg_profile_load_error, Toast.LENGTH_SHORT).show();
        }
    }

    // ==========================================
    // JSON & FILE HELPERS
    // ==========================================

    private JSONObject collectCurrentSettingsJson() throws Exception {
        JSONObject json = new JSONObject();
        
        json.put(KEY_ENABLED, getSecureInt(KEY_ENABLED, 1));
        json.put(KEY_LOGGING, getSecureInt(KEY_LOGGING, 0));
        json.put(KEY_PACKAGES_CONFIG, Settings.Secure.getString(mContext.getContentResolver(), KEY_PACKAGES_CONFIG));

        String[] floatKeys = {
            KEY_PULL_COEFF, KEY_STIFFNESS, KEY_DAMPING, KEY_FLING, KEY_RESISTANCE_EXPONENT,
            KEY_PHYSICS_MIN_VEL, KEY_PHYSICS_MIN_VAL, KEY_INPUT_SMOOTH_FACTOR,
            KEY_LERP_MAIN_IDLE, KEY_LERP_MAIN_RUN, KEY_LERP_FINGER_TRACK_PULL, KEY_LERP_FINGER_TRACK_RELEASE,
            KEY_FOLLOW_INTENSITY, KEY_TILT_INTENSITY, KEY_SCALE_INTENSITY, KEY_SCALE_LIMIT_MIN,
            KEY_SCALE_ANCHOR_Y, KEY_SCALE_ANCHOR_X, KEY_COEFF_ROT_Y, KEY_COEFF_ROT_X, KEY_COEFF_CAMERA
        };
        
        for (String k : floatKeys) {
            json.put(k, (double)getSecureFloat(k, 0));
        }

        String[] intKeys = {
            KEY_FOLLOW_ENABLE, KEY_SKEW_ENABLE, KEY_SCALE_MODE
        };
        
        for (String k : intKeys) {
            json.put(k, getSecureInt(k, 0));
        }

        // Visual Groups (scale, zoom, h_scale)
        String[] prefixes = {"overscroll_scale", "overscroll_zoom", "overscroll_h_scale"};
        for (String pre : prefixes) {
            json.put(pre + "_mode", getSecureInt(pre + "_mode", 0));
            json.put(pre + "_intensity", (double)getSecureFloat(pre + "_intensity", 0));
            json.put(pre + "_limit_min", (double)getSecureFloat(pre + "_limit_min", 0));
            json.put(pre + "_anchor_y", (double)getSecureFloat(pre + "_anchor_y", 0));
        }
        
        return json;
    }

    private void applySettingsFromJson(JSONObject json) {
        try {
            Iterator<String> keys = json.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                Object val = json.get(key);

                if (key.equals(KEY_PACKAGES_CONFIG)) {
                    Settings.Secure.putString(mContext.getContentResolver(), key, (String) val);
                } 
                else if (val instanceof Integer) {
                    putSecureInt(key, (Integer) val);
                } 
                else if (val instanceof Double || val instanceof Float) {
                    putSecureFloat(key, ((Number)val).floatValue());
                }
            }
            updateAllUiElements();
        } catch (Exception e) {
            Log.e(TAG, "Apply JSON Error", e);
        }
    }

    private void startFileExport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "overscroll_settings.json");
        startActivityForResult(intent, REQ_CREATE_FILE);
    }

    private void startFileImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_OPEN_FILE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_CREATE_FILE) {
            try {
                ParcelFileDescriptor pfd = mContext.getContentResolver().openFileDescriptor(uri, "w");
                if (pfd != null) {
                    FileOutputStream fos = new FileOutputStream(pfd.getFileDescriptor());
                    fos.write(collectCurrentSettingsJson().toString(4).getBytes());
                    fos.close();
                    pfd.close();
                    Toast.makeText(mContext, R.string.os_msg_exported, Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(mContext, R.string.os_msg_export_error, Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == REQ_OPEN_FILE) {
            try {
                StringBuilder sb = new StringBuilder();
                InputStream is = mContext.getContentResolver().openInputStream(uri);
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();
                is.close();
                applySettingsFromJson(new JSONObject(sb.toString()));
                Toast.makeText(mContext, R.string.os_msg_imported, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(mContext, R.string.os_msg_import_error, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void updateAllUiElements() {
        if (masterSwitchRef != null) {
            masterSwitchRef.setChecked(getSecureInt(KEY_ENABLED, 1) == 1);
        }
        for (Runnable r : uiUpdateRunnables) {
            if (r != null) r.run();
        }
        refreshConfiguredAppsList();
    }

    // ==========================================
    // SETUP METHODS
    // ==========================================

    private void setupBasic(View root) {
        LinearLayout container = root.findViewById(R.id.container_basic);
        if (container == null) return;

        addFloatControl(container, R.string.os_lbl_intensity, KEY_PULL_COEFF, 0.1f, 3.0f, 0.5f);
        addFloatControl(container, R.string.os_lbl_stiffness, KEY_STIFFNESS, 10f, 1000f, 450f);
        addFloatControl(container, R.string.os_lbl_damping, KEY_DAMPING, 0.1f, 2.0f, 0.7f);
        addFloatControl(container, R.string.os_lbl_fling, KEY_FLING, 0.1f, 3.0f, 0.6f);
        addFloatControl(container, R.string.os_lbl_res_exp, KEY_RESISTANCE_EXPONENT, 1f, 8f, 4.0f);
    }

    private void setupVisualGroups(View root) {
        // Keep old visual settings
        LinearLayout containerVisual = root.findViewById(R.id.container_visual);
        if (containerVisual != null) {
            setupSwitch(root, R.id.sw_follow_enable, KEY_FOLLOW_ENABLE, 0);
            setupSwitch(root, R.id.sw_skew_enable, KEY_SKEW_ENABLE, 0);
            setupRadioGroup(root, R.id.rg_scale_mode, KEY_SCALE_MODE, 0);
            setupRadioGroup(root, R.id.rg_anchor_y, KEY_SCALE_ANCHOR_Y, 0);
            setupRadioGroup(root, R.id.rg_anchor_x, KEY_SCALE_ANCHOR_X, 0);
            
            addFloatControl(containerVisual, R.string.os_lbl_follow_int, KEY_FOLLOW_INTENSITY, 0f, 2f, 0.0f);
            addFloatControl(containerVisual, R.string.os_lbl_scale_int, KEY_SCALE_INTENSITY, 0f, 1f, 0.0f);
            addFloatControl(containerVisual, R.string.os_lbl_tilt_int, KEY_TILT_INTENSITY, 0f, 2f, 0.0f);
            addFloatControl(containerVisual, R.string.os_lbl_rot_y, KEY_COEFF_ROT_Y, 0f, 90f, 45f);
            addFloatControl(containerVisual, R.string.os_lbl_rot_x, KEY_COEFF_ROT_X, 0f, 90f, 15f);
        }

        // New Visual Groups
        setupScaleGroup(root, R.id.container_visual_vert, "overscroll_scale", 0.0f, 0.5f, 0.5f);
        setupScaleGroup(root, R.id.container_visual_zoom, "overscroll_zoom", 0.0f, 0.5f, 0.5f);
        setupScaleGroup(root, R.id.container_visual_horz, "overscroll_h_scale", 0.0f, 0.5f, 0.5f);
    }

    private void setupScaleGroup(View root, int containerId, String prefix, float defInt, float defAX, float defAY) {
        LinearLayout container = root.findViewById(containerId);
        if (container == null) return;
        
        addModeSelector(container, prefix + "_mode");
        addFloatControl(container, R.string.os_lbl_scale_int, prefix + "_intensity", 0f, 1f, defInt);
        addFloatControl(container, R.string.os_lbl_scale_limit, prefix + "_limit_min", 0.1f, 1f, 0.3f);
        addFloatControl(container, R.string.os_lbl_anchor_y, prefix + "_anchor_y", 0f, 1f, defAY);
    }

    private void setupExperimental(View root) {
        LinearLayout container = root.findViewById(R.id.container_experimental);
        if (container == null) return;

        addLogLevelSelector(container);
        addFloatControl(container, R.string.os_lbl_input_smooth, KEY_INPUT_SMOOTH_FACTOR, 0f, 0.95f, 0.5f);
        addFloatControl(container, R.string.os_lbl_min_vel, KEY_PHYSICS_MIN_VEL, 0f, 10f, 1.0f);
        addFloatControl(container, R.string.os_lbl_min_val, KEY_PHYSICS_MIN_VAL, 0f, 5f, 0.5f);
        addFloatControl(container, R.string.os_lbl_camera, KEY_COEFF_CAMERA, 0.1f, 5f, 1.0f);
        addFloatControl(container, R.string.os_lbl_lerp_main_idle, KEY_LERP_MAIN_IDLE, 0.01f, 1f, 0.4f);
        addFloatControl(container, R.string.os_lbl_lerp_main_run, KEY_LERP_MAIN_RUN, 0.01f, 1f, 0.7f);
        addFloatControl(container, R.string.os_lbl_lerp_fin_pull, KEY_LERP_FINGER_TRACK_PULL, 0.01f, 1f, 0.3f);
        addFloatControl(container, R.string.os_lbl_lerp_fin_rel, KEY_LERP_FINGER_TRACK_RELEASE, 0.01f, 1f, 0.15f);
    }

    private void addLogLevelSelector(LinearLayout parent) {
        TextView title = new TextView(mContext);
        title.setText(R.string.os_lbl_logging);
        title.setTextColor(0xFFE6E1E5);
        title.setTextSize(16f);
        title.setPadding(0, 24, 0, 8);
        parent.addView(title);
        
        SeekBar seekBar = new SeekBar(mContext);
        seekBar.setMax(3);
        seekBar.setProgress(getSecureInt(KEY_LOGGING, 0));
        seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFD0BCFF));
        seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFD0BCFF));
        
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean f) {
                if (f) putSecureInt(KEY_LOGGING, p);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        
        parent.addView(seekBar);
        
        uiUpdateRunnables.add(() -> seekBar.setProgress(getSecureInt(KEY_LOGGING, 0)));
        globalResetActions.add(() -> {
            putSecureInt(KEY_LOGGING, 0);
            seekBar.setProgress(0);
        });
    }

    private void addModeSelector(LinearLayout parent, String key) {
        TextView title = new TextView(mContext);
        title.setText(R.string.os_lbl_scale_mode);
        title.setTextColor(0xFFE6E1E5);
        title.setTextSize(14f);
        title.setPadding(0, 16, 0, 8);
        
        RadioGroup rg = new RadioGroup(mContext);
        rg.setOrientation(LinearLayout.HORIZONTAL);
        rg.setWeightSum(3);
        
        String[] labels = {
            getString(R.string.os_mode_off), 
            getString(R.string.os_mode_shrink), 
            getString(R.string.os_mode_grow)
        };
        
        for (int i = 0; i < 3; i++) {
            RadioButton rb = new RadioButton(mContext);
            rb.setText(labels[i]);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            );
            rb.setLayoutParams(p);
            rb.setTextColor(0xFFCAC4D0);
            rg.addView(rb);
            if (getSecureInt(key, 0) == i) rb.setChecked(true);
        }
        
        rg.setOnCheckedChangeListener((group, checkedId) -> {
            View rb = group.findViewById(checkedId);
            int idx = group.indexOfChild(rb);
            if (idx != -1) putSecureInt(key, idx);
        });
        
        uiUpdateRunnables.add(() -> {
            int val = getSecureInt(key, 0);
            if (val >= 0 && val < rg.getChildCount()) {
                ((RadioButton)rg.getChildAt(val)).setChecked(true);
            }
        });
        
        LinearLayout header = new LinearLayout(mContext);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        
        SettingInfo info = getInfoForKey(key);
        if (info != null) header.addView(createInfoIcon(info));
        header.addView(title);
        
        parent.addView(header);
        parent.addView(rg);
        
        globalResetActions.add(() -> {
            putSecureInt(key, 0);
            if (rg.getChildCount() > 0) ((RadioButton)rg.getChildAt(0)).setChecked(true);
        });
    }

    // ==========================================
    // PER-APP CONFIGURATION
    // ==========================================

    private static class AppConfigItem {
        String pkg;
        boolean filter;
        float scale;
        boolean ignore;
        
        AppConfigItem(String p, boolean f, float s, boolean i) {
            pkg = p;
            filter = f;
            scale = s;
            ignore = i;
        }
        
        public String toString() {
            return pkg + ":" + (filter ? "1" : "0") + ":" + 
                   String.format(Locale.US, "%.2f", scale) + ":" + 
                   (ignore ? "1" : "0");
        }
    }

    private void setupAppConfig(View root) {
        appsContainer = root.findViewById(R.id.ll_apps_list);
        Button btnAdd = root.findViewById(R.id.btn_add_app);
        if (btnAdd != null) {
            btnAdd.setOnClickListener(v -> showAppSelectorDialog());
        }
        refreshConfiguredAppsList();
    }

    private List<AppConfigItem> parseAppConfig() {
        List<AppConfigItem> list = new ArrayList<>();
        String raw = Settings.Secure.getString(mContext.getContentResolver(), KEY_PACKAGES_CONFIG);
        if (raw == null || raw.isEmpty()) return list;

        String[] apps = raw.split(" ");
        for (String app : apps) {
            try {
                String[] parts = app.split(":");
                if (parts.length >= 3) {
                    String pkg = parts[0];
                    boolean filter = parts[1].equals("1");
                    float scale = Float.parseFloat(parts[2]);
                    boolean ignore = (parts.length >= 4) && parts[3].equals("1");
                    list.add(new AppConfigItem(pkg, filter, scale, ignore));
                }
            } catch (Exception e) {
                Log.e(TAG, "Error parsing app config: " + app, e);
            }
        }
        return list;
    }

    private void saveAppConfig(List<AppConfigItem> list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            sb.append(list.get(i).toString());
            if (i < list.size() - 1) sb.append(" ");
        }
        Settings.Secure.putString(mContext.getContentResolver(), KEY_PACKAGES_CONFIG, sb.toString());
    }

    private void refreshConfiguredAppsList() {
        if (appsContainer == null) return;
        appsContainer.removeAllViews();

        List<AppConfigItem> configs = parseAppConfig();
        PackageManager pm = mContext.getPackageManager();

        for (AppConfigItem item : configs) {
            View card = LayoutInflater.from(mContext).inflate(R.layout.item_app_config, appsContainer, false);
            
            ImageView icon = card.findViewById(R.id.img_app_icon);
            TextView name = card.findViewById(R.id.tv_app_name);
            TextView pkgName = card.findViewById(R.id.tv_pkg_name);
            Switch swFilter = card.findViewById(R.id.sw_app_filter);
            SeekBar sbScale = card.findViewById(R.id.sb_app_scale);
            TextView tvScaleVal = card.findViewById(R.id.tv_scale_val);
            Switch swIgnore = card.findViewById(R.id.sw_app_ignore);

            card.findViewById(R.id.btn_delete_app).setOnClickListener(v -> {
                configs.remove(item);
                saveAppConfig(configs);
                refreshConfiguredAppsList();
            });

            try {
                ApplicationInfo info = pm.getApplicationInfo(item.pkg, 0);
                icon.setImageDrawable(pm.getApplicationIcon(info));
                name.setText(pm.getApplicationLabel(info));
            } catch (Exception e) {
                name.setText(item.pkg);
            }
            pkgName.setText(item.pkg);

            swFilter.setChecked(item.filter);
            sbScale.setProgress((int)(item.scale * 100));
            tvScaleVal.setText(String.format(Locale.US, "%.1f", item.scale));
            
            if (swIgnore != null) {
                swIgnore.setChecked(item.ignore);
                swIgnore.setOnCheckedChangeListener((v, c) -> {
                    item.ignore = c;
                    saveAppConfig(configs);
                });
            }

            swFilter.setOnCheckedChangeListener((v, c) -> {
                item.filter = c;
                saveAppConfig(configs);
            });

            sbScale.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar s, int p, boolean f) {
                    if (f) tvScaleVal.setText(String.format(Locale.US, "%.1f", p / 100f));
                }
                @Override
                public void onStopTrackingTouch(SeekBar s) {
                    item.scale = s.getProgress() / 100f;
                    saveAppConfig(configs);
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
            });

            appsContainer.addView(card);
        }
    }

    private void showAppSelectorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        View view = LayoutInflater.from(mContext).inflate(R.layout.dialog_app_selector, null);
        builder.setView(view);
        AlertDialog dialog = builder.create();
        
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        EditText search = view.findViewById(R.id.et_search);
        ListView listView = view.findViewById(R.id.lv_apps);
        View loading = view.findViewById(R.id.ll_loading);
        
        view.findViewById(R.id.btn_cancel_selector).setOnClickListener(v -> dialog.dismiss());

        new Thread(() -> {
            PackageManager pm = mContext.getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            List<AppItem> appItems = new ArrayList<>();
            
            for (ApplicationInfo app : apps) {
                appItems.add(new AppItem(
                    app.loadLabel(pm).toString(),
                    app.packageName,
                    app.loadIcon(pm)
                ));
            }
            
            Collections.sort(appItems, (o1, o2) -> o1.name.compareToIgnoreCase(o2.name));

            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    loading.setVisibility(View.GONE);
                    listView.setVisibility(View.VISIBLE);
                    
                    AppAdapter adapter = new AppAdapter(mContext, appItems);
                    listView.setAdapter(adapter);
                    
                    search.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                        
                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            adapter.getFilter().filter(s);
                        }
                        
                        @Override
                        public void afterTextChanged(Editable s) {}
                    });
                    
                    listView.setOnItemClickListener((p, v, pos, id) -> {
                        AppItem selected = adapter.getItem(pos);
                        addAppToConfig(selected.pkg);
                        dialog.dismiss();
                    });
                });
            }
        }).start();

        dialog.show();
    }

    private void addAppToConfig(String pkg) {
        List<AppConfigItem> current = parseAppConfig();
        for (AppConfigItem item : current) {
            if (item.pkg.equals(pkg)) return;
        }
        current.add(new AppConfigItem(pkg, false, 1.0f, false));
        saveAppConfig(current);
        refreshConfiguredAppsList();
    }

    private static class AppItem {
        String name;
        String pkg;
        Drawable icon;
        
        AppItem(String n, String p, Drawable i) {
            name = n;
            pkg = p;
            icon = i;
        }
        
        @Override
        public String toString() {
            return name;
        }
    }

    private class AppAdapter extends ArrayAdapter<AppItem> {
        private List<AppItem> originalList;
        private List<AppItem> filteredList;
        private Filter filter;

        public AppAdapter(Context ctx, List<AppItem> items) {
            super(ctx, 0, items);
            this.originalList = new ArrayList<>(items);
            this.filteredList = items;
        }

        @Override
        public int getCount() {
            return filteredList.size();
        }

        @Override
        public AppItem getItem(int position) {
            return filteredList.get(position);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(
                    android.R.layout.simple_list_item_1, parent, false
                );
                ((TextView)convertView.findViewById(android.R.id.text1)).setTextColor(Color.WHITE);
            }
            
            AppItem item = getItem(position);
            TextView tv = convertView.findViewById(android.R.id.text1);
            tv.setText(item.name + "\n" + item.pkg);
            
            if (item.icon != null) {
                item.icon.setBounds(0, 0, 96, 96);
                tv.setCompoundDrawables(item.icon, null, null, null);
                tv.setCompoundDrawablePadding(24);
            }
            
            return convertView;
        }

        @Override
        public Filter getFilter() {
            if (filter == null) {
                filter = new Filter() {
                    @Override
                    protected FilterResults performFiltering(CharSequence constraint) {
                        FilterResults results = new FilterResults();
                        List<AppItem> resList = new ArrayList<>();
                        
                        if (constraint == null || constraint.length() == 0) {
                            resList.addAll(originalList);
                        } else {
                            String pattern = constraint.toString().toLowerCase().trim();
                            for (AppItem i : originalList) {
                                if (i.name.toLowerCase().contains(pattern) || 
                                    i.pkg.toLowerCase().contains(pattern)) {
                                    resList.add(i);
                                }
                            }
                        }
                        
                        results.values = resList;
                        results.count = resList.size();
                        return results;
                    }

                    @Override
                    protected void publishResults(CharSequence constraint, FilterResults results) {
                        filteredList = (List<AppItem>) results.values;
                        notifyDataSetChanged();
                    }
                };
            }
            return filter;
        }
    }

    // ==========================================
    // GLOBAL RESET
    // ==========================================

    private void setupGlobalReset(View root) {
        View btn = root.findViewById(R.id.btn_reset);
        if (btn != null) {
            btn.setOnClickListener(v -> {
                new AlertDialog.Builder(mContext)
                    .setTitle(R.string.os_dialog_reset_title)
                    .setMessage(R.string.os_dialog_reset_msg)
                    .setPositiveButton(R.string.os_btn_reset, (d, w) -> {
                        for (Runnable r : globalResetActions) r.run();
                        Toast.makeText(mContext, R.string.os_msg_reset_done, Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton(R.string.os_btn_cancel, null)
                    .show();
            });
        }
    }

    // ==========================================
    // CONTROLS GENERATOR
    // ==========================================

    private void addFloatControl(LinearLayout parent, @StringRes int titleResId, String key, float min, float max, float defVal) {
        if (parent == null) return;

        LinearLayout row = new LinearLayout(mContext);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, 24, 0, 8);
        
        LinearLayout header = new LinearLayout(mContext);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        
        SettingInfo info = getInfoForKey(key);
        if (info != null) {
            header.addView(createInfoIcon(info));
        }

        TextView tvTitle = new TextView(mContext);
        tvTitle.setText(titleResId);
        tvTitle.setTextColor(0xFFE6E1E5);
        tvTitle.setTextSize(16f);
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        
        TextView tvValue = new TextView(mContext);
        tvValue.setTextColor(0xFF381E72);
        tvValue.setTextSize(14f);
        tvValue.setPadding(32, 10, 32, 10);
        
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0xFFD0BCFF);
        pill.setCornerRadius(100f);
        tvValue.setBackground(pill);
        tvValue.setGravity(Gravity.CENTER);
        tvValue.setClickable(true);
        tvValue.setElevation(4f);
        
        header.addView(tvTitle);
        header.addView(tvValue);
        row.addView(header);

        SeekBar seekBar = new SeekBar(mContext);
        seekBar.setMax(1000);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.topMargin = 24;
        seekBar.setLayoutParams(lp);
        seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFD0BCFF));
        seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFD0BCFF));
        
        row.addView(seekBar);

        View divider = new View(mContext);
        divider.setBackgroundColor(0xFF333333);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 2
        );
        divLp.topMargin = 24;
        divider.setLayoutParams(divLp);
        divider.setAlpha(0.3f);
        row.addView(divider);

        parent.addView(row);

        Runnable updateUi = () -> {
            float val = getSecureFloat(key, defVal);
            float displayProgress = val;
            if (displayProgress < min && min != 0) displayProgress = min;
            
            tvValue.setText(String.format(Locale.US, "%.2f", val));
            int progress = (int) ((displayProgress - min) / (max - min) * 1000);
            seekBar.setProgress(Math.max(0, Math.min(1000, progress)));
        };

        updateUi.run();
        uiUpdateRunnables.add(updateUi);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    float val = min + (progress / 1000f) * (max - min);
                    tvValue.setText(String.format(Locale.US, "%.2f", val));
                    putSecureFloat(key, val);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        tvValue.setOnClickListener(v -> showEditDialog(titleResId, key, min, max, defVal, updateUi));

        globalResetActions.add(() -> {
            putSecureFloat(key, defVal);
            updateUi.run();
        });
    }

    private ImageView createInfoIcon(SettingInfo info) {
        ImageView iconInfo = new ImageView(mContext);
        iconInfo.setImageResource(R.drawable.ic_info_outline);
        LinearLayout.LayoutParams icParams = new LinearLayout.LayoutParams(56, 56);
        icParams.setMarginEnd(16);
        iconInfo.setLayoutParams(icParams);
        iconInfo.setClickable(true);
        iconInfo.setAlpha(0.7f);
        iconInfo.setOnClickListener(v -> showDescriptionDialog(info));
        return iconInfo;
    }

    // ==========================================
    // DIALOGS
    // ==========================================

    private void showDescriptionDialog(SettingInfo info) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        View view = LayoutInflater.from(mContext).inflate(R.layout.dialog_info, null);
        builder.setView(view);
        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        TextView tvTitle = view.findViewById(R.id.info_title);
        TextView tvDesc = view.findViewById(R.id.info_desc);
        VideoView videoView = view.findViewById(R.id.info_video);
        View videoContainer = view.findViewById(R.id.video_container);
        Button btnClose = view.findViewById(R.id.btn_close);

        tvTitle.setText(getString(info.titleRes));
        tvDesc.setText(android.text.Html.fromHtml(
            getString(info.descRes), 
            android.text.Html.FROM_HTML_MODE_COMPACT
        ));

        int resId = 0;
        if (info.videoName != null) {
            resId = getResources().getIdentifier(info.videoName, "raw", mContext.getPackageName());
        }

        if (resId != 0) {
            videoContainer.setVisibility(View.VISIBLE);
            videoContainer.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), 32f);
                }
            });
            videoContainer.setClipToOutline(true);

            String path = "android.resource://" + mContext.getPackageName() + "/" + resId;
            videoView.setVideoURI(Uri.parse(path));
            videoView.setOnPreparedListener(mp -> {
                mp.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
                mp.setLooping(true);
                videoView.start();
            });
        } else {
            videoContainer.setVisibility(View.GONE);
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showEditDialog(@StringRes int titleResId, String key, float min, float max, float defVal, Runnable onUpdate) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle(titleResId);

        final EditText input = new EditText(mContext);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setText(String.valueOf(getSecureFloat(key, defVal)));
        input.setGravity(Gravity.CENTER);
        
        LinearLayout container = new LinearLayout(mContext);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(60, 20, 60, 20);
        container.addView(input);
        builder.setView(container);

        builder.setPositiveButton(R.string.os_btn_apply, (dialog, which) -> {
            try {
                String text = input.getText().toString();
                if (!text.isEmpty()) {
                    float val = Float.parseFloat(text);
                    putSecureFloat(key, val);
                    onUpdate.run();
                }
            } catch (NumberFormatException e) {
                Log.e(TAG, "Invalid number format", e);
            }
        });

        builder.setNeutralButton(R.string.os_btn_default, (dialog, which) -> {
            putSecureFloat(key, defVal);
            onUpdate.run();
        });

        builder.setNegativeButton(R.string.os_btn_cancel, null);
        builder.show();
    }

    // ==========================================
    // HELPERS
    // ==========================================

    private void setupSwitch(View root, int id, String key, int defVal) {
        Switch sw = root.findViewById(id);
        if (sw == null) return;
        sw.setChecked(getSecureInt(key, defVal) == 1);
        sw.setOnCheckedChangeListener((v, c) -> putSecureInt(key, c ? 1 : 0));
        
        uiUpdateRunnables.add(() -> sw.setChecked(getSecureInt(key, defVal) == 1));
        
        globalResetActions.add(() -> {
            putSecureInt(key, defVal);
            sw.setChecked(defVal == 1);
        });
    }

    private void setupRadioGroup(View root, int id, String key, int defVal) {
        RadioGroup rg = root.findViewById(id);
        if (rg == null) return;
        int current = getSecureInt(key, defVal);
        if (current >= 0 && current < rg.getChildCount()) {
            ((RadioButton) rg.getChildAt(current)).setChecked(true);
        }
        rg.setOnCheckedChangeListener((g, i) -> {
            View rb = g.findViewById(i);
            int idx = g.indexOfChild(rb);
            if (idx != -1) putSecureInt(key, idx);
        });
        
        uiUpdateRunnables.add(() -> {
            int val = getSecureInt(key, defVal);
            if (val >= 0 && val < rg.getChildCount()) {
                ((RadioButton) rg.getChildAt(val)).setChecked(true);
            }
        });
        
        globalResetActions.add(() -> {
            putSecureInt(key, defVal);
            if (defVal < rg.getChildCount()) {
                ((RadioButton) rg.getChildAt(defVal)).setChecked(true);
            }
        });
    }

    private float getSecureFloat(String key, float def) {
        try {
            return Settings.Secure.getFloat(mContext.getContentResolver(), key, def);
        } catch (Exception e) {
            return def;
        }
    }

    private void putSecureFloat(String key, float val) {
        try {
            Settings.Secure.putFloat(mContext.getContentResolver(), key, val);
        } catch (Exception e) {
            Log.e(TAG, "Error putting float: " + key, e);
        }
    }

    private int getSecureInt(String key, int def) {
        try {
            return Settings.Secure.getInt(mContext.getContentResolver(), key, def);
        } catch (Exception e) {
            return def;
        }
    }

    private void putSecureInt(String key, int val) {
        try {
            Settings.Secure.putInt(mContext.getContentResolver(), key, val);
        } catch (Exception e) {
            Log.e(TAG, "Error putting int: " + key, e);
        }
    }

    private SettingInfo getInfoForKey(String key) {
        switch (key) {
            case KEY_PULL_COEFF: 
                return new SettingInfo(R.string.title_pull, R.string.desc_pull, "demo_pull");
            case KEY_STIFFNESS: 
                return new SettingInfo(R.string.title_stiffness, R.string.desc_stiffness, "demo_stiffness");
            case KEY_DAMPING: 
                return new SettingInfo(R.string.title_damping, R.string.desc_damping, "demo_damping");
            case KEY_FLING: 
                return new SettingInfo(R.string.title_fling, R.string.desc_fling, "demo_fling");
            case KEY_FOLLOW_INTENSITY: 
                return new SettingInfo(R.string.title_follow, R.string.desc_follow, "demo_follow");
            case KEY_SKEW_ENABLE: 
                return new SettingInfo(R.string.title_skew, R.string.desc_skew, "demo_skew");
            case KEY_TILT_INTENSITY: 
                return new SettingInfo(R.string.title_tilt_intensity, R.string.desc_tilt_intensity, null);
            case KEY_COEFF_ROT_Y: 
                return new SettingInfo(R.string.title_rot_y, R.string.desc_rot_y, "demo_skew_y");
            case KEY_COEFF_ROT_X: 
                return new SettingInfo(R.string.title_rot_x, R.string.desc_rot_x, "demo_skew_x");
            case KEY_SCALE_MODE: 
                return new SettingInfo(R.string.title_scale_mode, R.string.desc_scale_mode, "demo_scale");
            case KEY_SCALE_INTENSITY: 
                return new SettingInfo(R.string.title_scale_intensity, R.string.desc_scale_intensity, null);
            case KEY_SCALE_LIMIT_MIN: 
                return new SettingInfo(R.string.title_scale_limit, R.string.desc_scale_limit, null);
            case KEY_SCALE_ANCHOR_Y:
            case KEY_SCALE_ANCHOR_X: 
                return new SettingInfo(R.string.title_anchor, R.string.desc_anchor, "demo_anchor");
            case KEY_INPUT_SMOOTH_FACTOR: 
                return new SettingInfo(R.string.title_input_smooth, R.string.desc_input_smooth, null);
            case KEY_RESISTANCE_EXPONENT: 
                return new SettingInfo(R.string.title_res_exp, R.string.desc_res_exp, null);
            case KEY_PHYSICS_MIN_VEL: 
                return new SettingInfo(R.string.title_min_vel, R.string.desc_min_vel, null);
            case KEY_PHYSICS_MIN_VAL: 
                return new SettingInfo(R.string.title_min_val, R.string.desc_min_val, null);
            case KEY_COEFF_CAMERA: 
                return new SettingInfo(R.string.title_camera, R.string.desc_camera, null);
            case KEY_LERP_MAIN_IDLE:
            case KEY_LERP_MAIN_RUN:
            case KEY_LERP_FINGER_TRACK_PULL:
            case KEY_LERP_FINGER_TRACK_RELEASE: 
                return new SettingInfo(R.string.title_lerp, R.string.desc_lerp, null);
            default: 
                return null;
        }
    }

    private static class SettingInfo {
        int titleRes, descRes;
        String videoName;
        
        SettingInfo(int t, int d, String v) {
            titleRes = t;
            descRes = d;
            videoName = v;
        }
    }
}